<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Imports\JplImport;
use App\Models\Jpl;
use App\Models\Resort;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;

class JplImportController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Halaman Upload
    |--------------------------------------------------------------------------
    */

    public function create()
    {
        return 'TEST HALAMAN IMPORT';
    }


    /*
    |--------------------------------------------------------------------------
    | Upload & Preview
    |--------------------------------------------------------------------------
    */

    public function preview(Request $request)
    {
        /*
        |--------------------------------------------------------------------------
        | Validasi File
        |--------------------------------------------------------------------------
        */

        $request->validate([
            'file' => [
                'required',
                'file',
                'mimes:xlsx,xls',
                'max:10240',
            ],
        ]);


        /*
        |--------------------------------------------------------------------------
        | Baca Excel
        |--------------------------------------------------------------------------
        |
        | JplImport hanya membaca data.
        | Belum ada data yang disimpan ke database.
        |
        */

        $import = new JplImport();

        Excel::import(
            $import,
            $request->file('file')
        );

        $rows = collect($import->rows);


        /*
        |--------------------------------------------------------------------------
        | Ambil Nama Resort
        |--------------------------------------------------------------------------
        */

        $resortNames = $rows
            ->pluck('resort')
            ->filter()
            ->map(fn ($name) => trim($name))
            ->unique()
            ->values();


        /*
        |--------------------------------------------------------------------------
        | Ambil Resort dari Database
        |--------------------------------------------------------------------------
        */

        $existingResorts = Resort::whereIn(
            'nama_resort',
            $resortNames
        )
            ->pluck('nama_resort')
            ->map(fn ($name) => trim($name))
            ->values();


        /*
        |--------------------------------------------------------------------------
        | Validasi Setiap Baris
        |--------------------------------------------------------------------------
        */

        $previewRows = $rows
            ->map(function ($row) use ($existingResorts) {

                $row['status'] = 'valid';
                $row['errors'] = [];


                /*
                |--------------------------------------------------------------------------
                | Validasi Resort
                |--------------------------------------------------------------------------
                */

                if (empty($row['resort'])) {

                    $row['status'] = 'error';

                    $row['errors'][] = 'RESORT kosong.';

                } elseif (
                    ! $existingResorts->contains(
                        trim($row['resort'])
                    )
                ) {

                    $row['status'] = 'error';

                    $row['errors'][] =
                        'Resort belum tersedia di database.';
                }


                /*
                |--------------------------------------------------------------------------
                | Validasi Nama JPL
                |--------------------------------------------------------------------------
                */

                if ($row['nama_jpl'] === null) {

                    $row['status'] = 'error';

                    $row['errors'][] =
                        'NAMA JLN / DAERAH kosong.';
                }


                /*
                |--------------------------------------------------------------------------
                | Validasi No JPL
                |--------------------------------------------------------------------------
                |
                | Nilai "Liar" adalah data resmi.
                | Nilai tersebut tetap dianggap valid.
                |
                */

                if ($row['kode_jpl'] === null) {

                    $row['status'] = 'error';

                    $row['errors'][] =
                        'NO JPL kosong.';
                }


                return $row;

            })
            ->values();


        /*
        |--------------------------------------------------------------------------
        | Simpan Hasil Preview ke Session
        |--------------------------------------------------------------------------
        */

        session([
            'jpl_import' => [
                'rows' => $previewRows->all(),
                'total' => $previewRows->count(),
            ],
        ]);


        /*
        |--------------------------------------------------------------------------
        | Redirect ke Halaman Preview
        |--------------------------------------------------------------------------
        */

        return redirect()
            ->route('admin.jpl.import.preview');
    }


    /*
    |--------------------------------------------------------------------------
    | Halaman Preview
    |--------------------------------------------------------------------------
    */

    public function showPreview()
    {
        $import = session('jpl_import', []);

        return view('admin.jpl.import-preview', [
            'rows' => $import['rows'] ?? [],
            'total' => $import['total'] ?? 0,
        ]);
    }


    /*
    |--------------------------------------------------------------------------
    | Confirm Import
    |--------------------------------------------------------------------------
    */

    public function confirm()
    {
        $import = session('jpl_import');


        /*
        |--------------------------------------------------------------------------
        | Pastikan Preview Masih Ada
        |--------------------------------------------------------------------------
        */

        if (! $import || empty($import['rows'])) {

            return redirect()
                ->route('admin.jpl.import')
                ->with(
                    'error',
                    'Data preview import tidak ditemukan.'
                );
        }


        $rows = collect($import['rows']);


        /*
        |--------------------------------------------------------------------------
        | Jangan Simpan Jika Ada Error
        |--------------------------------------------------------------------------
        */

        $errorRows = $rows->filter(
            fn ($row) =>
                ($row['status'] ?? 'error') === 'error'
        );


        if ($errorRows->isNotEmpty()) {

            return redirect()
                ->route('admin.jpl.import.preview')
                ->with(
                    'error',
                    'Import tidak dapat dilakukan karena masih terdapat data yang tidak valid.'
                );
        }


        /*
        |--------------------------------------------------------------------------
        | Simpan ke Database
        |--------------------------------------------------------------------------
        |
        | Semua data diproses dalam satu transaction.
        |
        | Jika terjadi error di tengah proses,
        | seluruh proses akan di-rollback.
        |
        */

        DB::transaction(function () use ($rows) {

            foreach ($rows as $row) {

                /*
                |--------------------------------------------------------------------------
                | Cari Resort
                |--------------------------------------------------------------------------
                */

                $resort = Resort::where(
                    'nama_resort',
                    trim($row['resort'])
                )->first();


                /*
                |--------------------------------------------------------------------------
                | Safety Check
                |--------------------------------------------------------------------------
                */

                if (! $resort) {

                    throw new \RuntimeException(
                        'Resort tidak ditemukan: ' .
                        $row['resort']
                    );
                }


                /*
                |--------------------------------------------------------------------------
                | Buat Data JPL
                |--------------------------------------------------------------------------
                */

                Jpl::create([

                    'kode_jpl' =>
                        $row['kode_jpl'],

                    'nama_jpl' =>
                        $row['nama_jpl'],

                    'resort_id' =>
                        $resort->id,

                    'antara' =>
                        $row['antara'],

                    'km_hm' =>
                        $row['km_hm'],

                    'kota_kabupaten' =>
                        $row['kota_kabupaten'],

                    'provinsi' =>
                        $row['provinsi'],

                    'jenis_jalur_ka' =>
                        $row['jenis_jalur_ka'],

                    'titik_koordinat' =>
                        $row['titik_koordinat'],

                    'status_penjagaan' =>
                        $row['status_penjagaan'],

                    'is_active' =>
                        true,
                ]);
            }
        });


        /*
        |--------------------------------------------------------------------------
        | Hapus Session Preview
        |--------------------------------------------------------------------------
        */

        session()->forget('jpl_import');


        /*
        |--------------------------------------------------------------------------
        | Kembali ke Master JPL
        |--------------------------------------------------------------------------
        */

        return redirect()
            ->route('admin.jpl.index')
            ->with(
                'success',
                'Data JPL berhasil diimport.'
            );
    }
}