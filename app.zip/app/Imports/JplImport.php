<?php

namespace App\Imports;

use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class JplImport implements ToCollection, WithHeadingRow
{
    public array $rows = [];

    public function collection(Collection $collection): void
    {
        foreach ($collection as $index => $row) {
            $this->rows[] = [
                'row' => $index + 2,

                'resort' => $this->value($row, 'resort'),
                'antara' => $this->value($row, 'antara'),
                'km_hm' => $this->value($row, 'km_hm'),
                'kode_jpl' => $this->value($row, 'no_jpl'),
                'nama_jpl' => $this->value($row, 'nama_jln_daerah'),
                'kota_kabupaten' => $this->value($row, 'kota_kabupaten'),
                'provinsi' => $this->value($row, 'provinsi'),
                'jenis_jalur_ka' => $this->value($row, 'jenis_jalur_ka'),
                'titik_koordinat' => $this->value($row, 'titik_koordinat'),
                'status_penjagaan' => $this->value($row, 'status_penjagaan'),
            ];
        }
    }

    private function value(Collection|array $row, string $key): ?string
    {
        $value = $row[$key] ?? null;

        if ($value === null) {
            return null;
        }

        $value = trim((string) $value);

        return $value === '' ? null : $value;
    }
}